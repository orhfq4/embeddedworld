/*
 * Temperature_Sensor.h
 *
 * Created: 7/2/2020 3:11:40 PM
 *  Author: youngerr
 */ 


#ifndef TEMPERATURE_SENSOR_H_
#define TEMPERATURE_SENSOR_H_

void Temperature_Sensor_Init(void);
uint16_t Temperature_Read(void);



#endif /* TEMPERATURE_SENSOR_H_ */