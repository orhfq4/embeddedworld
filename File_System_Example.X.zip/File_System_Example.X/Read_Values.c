
#include "Read_Values.h"
#include "peripherals.h"
uint8_t read_value_8(uint16_t offset, uint8_t array[])
{
    
}


uint16_t read_value_16(uint16_t offset, uint8_t array[])
{
    
}
uint32_t read_value_32(uint16_t offset, uint8_t array[])
{
    
}
