#include "board.h"
#include "LEDS.h"
#include "GPIO_Outputs.h"


led_inst_t led0, led1, led2, led3;



