#include "board.h"
#include "LEDS.h"


led_inst_t led0, led1, led2, led3;


