/* 
 * File:   timer2.h
 * Author: Younger
 *
 * Created on December 5, 2024, 3:53 PM
 */

#ifndef TIMER2_H
#define	TIMER2_H

#include "peripherals.h"

//*** Define timer initialization 

uint8_t Timer2_Init(uint8_t interval_ms)

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* TIMER2_H */

