/* 
 * File:   board.c
 * Author: owenhancock
 *
 * Created on September 17, 2024, 11:02 AM
 */

#include "board.h"

// Define LED3 instance;
LED_t LED3;
